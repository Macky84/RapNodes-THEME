<?php

return [
    'exceptions' => [
        'user_has_servers' => 'Es kann kein Benutzer mit einem aktiven Server gelöscht werden.',
    ],
    'notices' => [
        'account_created' => 'Der Account wurde erfolgreich erstellt.',
        'account_updated' => 'Der Account wurde erfolgreich bearbeitet.',
    ],
];
