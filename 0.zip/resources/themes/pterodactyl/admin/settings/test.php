<?php
$color = $_POST['primary_color'];
echo $color;
?>